#!/usr/bin/env python3

import subprocess

ipAddress = "10.10.10.10"
"""
command = ["mesaflash", "--device", "7i96", "--addr", ipAddress, "--readhmid"]

result = subprocess.getstatusoutput(command)

print(f"exitcode {result[0]}")

print(f"output {result[1]}")
"""
command = f"mesaflash --device 7i96 --addr {ipAddress} --readhmid"

result = subprocess.getstatusoutput(command)

print(f"exitcode {result[0]}")

print(f"output {result[1]}")
