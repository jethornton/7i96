# Mesa 7i96 Configuration Tool

The 7i96 Configuration Tool will create a complete configuration from scratch.

Read in the ini configuration file for changes.

You can create a configuration then run it with the Axis GUI and use
Machine > Calibration to tune each axis. Save the values to the ini file and
next time you run the 7i96 Configuration Tool it will read the values from the
ini file.

See the [documentation](https://jethornton.github.io/7i96/) for installation and
usage instructions.

Note: The master branch might be broken from time to time while I improve the
configuration tool. The 1.1 branch should be stable.
