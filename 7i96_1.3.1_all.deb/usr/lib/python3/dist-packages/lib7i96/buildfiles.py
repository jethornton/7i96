import os
from datetime import datetime

def build(parent):
	parent.outputPTE.appendPlainText('Building Configuration Files')
	#builddirs(parent)
	#buildini(parent)
	#buildhal(parent)
	#buildio(parent)
	buildmisc(parent)




